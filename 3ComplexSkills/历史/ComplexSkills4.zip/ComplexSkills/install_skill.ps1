param(
  [string]$ClaudeSkillsDir = "$env:USERPROFILE\.claude\skills",
  [string]$SkillName = "ComplexSkills",
  [switch]$DryRun,
  [switch]$RunSelfTest
)
$ErrorActionPreference = "Stop"
$Root = (Resolve-Path (Split-Path -Parent $MyInvocation.MyCommand.Path)).Path
$Target = Join-Path $ClaudeSkillsDir $SkillName
$ResolvedTarget = $null
if (Test-Path $Target) { $ResolvedTarget = (Resolve-Path $Target).Path }

if (!(Test-Path (Join-Path $Root "SKILL.md"))) { throw "Root SKILL.md not found: $Root" }
if (!(Test-Path (Join-Path $Root "_shared"))) { throw "_shared directory not found: $Root" }
if (!(Test-Path (Join-Path $Root "skills"))) { throw "skills directory not found: $Root" }
if (!(Test-Path $ClaudeSkillsDir)) { New-Item -ItemType Directory -Force -Path $ClaudeSkillsDir | Out-Null }

if ($DryRun) {
  Write-Host "DRY-RUN single-skill install $Root -> $Target"
  Write-Host "This preserves SKILL.md, _shared, skills, templates, tests, dashboard, quality gate, and scripts together."
  exit 0
}

if ($ResolvedTarget -and ($ResolvedTarget -ieq $Root)) {
  Write-Host "Source is already the target Skill directory: $Target"
} else {
  if (Test-Path $Target) {
    $backup = "$Target.backup_$(Get-Date -Format yyyyMMdd_HHmmss)"
    Move-Item -LiteralPath $Target -Destination $backup
    Write-Host "Backed up existing $Target -> $backup"
  }
  New-Item -ItemType Directory -Force -Path $Target | Out-Null
  Get-ChildItem -LiteralPath $Root -Force | ForEach-Object {
    Copy-Item -LiteralPath $_.FullName -Destination $Target -Recurse -Force
  }
  Write-Host "Installed single skill directory: $Target"
}

if ($RunSelfTest) {
  Push-Location $Target
  try {
    python tools/selftest.py
  } finally {
    Pop-Location
  }
}
