# Renderer C10-arbitrary-file-read

This renderer is template-specific. Required evidence fields are loaded from `_shared/vulnerability_templates/canonical_23/C10-arbitrary-file-read/evidence.json`. Generic confirmed reports are forbidden.
