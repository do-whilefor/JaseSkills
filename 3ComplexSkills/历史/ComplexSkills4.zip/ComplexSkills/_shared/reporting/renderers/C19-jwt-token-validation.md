# Renderer C19-jwt-token-validation

This renderer is template-specific. Required evidence fields are loaded from `_shared/vulnerability_templates/canonical_23/C19-jwt-token-validation/evidence.json`. Generic confirmed reports are forbidden.
