# Renderer C07-command-injection

This renderer is template-specific. Required evidence fields are loaded from `_shared/vulnerability_templates/canonical_23/C07-command-injection/evidence.json`. Generic confirmed reports are forbidden.
