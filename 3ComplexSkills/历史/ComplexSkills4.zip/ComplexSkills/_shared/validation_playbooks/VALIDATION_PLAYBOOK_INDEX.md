# VALIDATION_PLAYBOOK_INDEX

每类漏洞的验证剧本位于对应研究单元 `VALIDATION_PLAYBOOK.md`。所有剧本只适用于本机授权、非破坏性环境。

| 类型 | 路径 |
|---|---|
| V01 认证绕过 | `_shared/vulnerability_research_units/V01-auth-bypass/playbook.md` |
| V02 权限绕过 | `_shared/vulnerability_research_units/V02-authz-bypass/playbook.md` |
| V03 IDOR / BOLA | `_shared/vulnerability_research_units/V03-idor-bola/playbook.md` |
| V04 租户隔离绕过 | `_shared/vulnerability_research_units/V04-tenant-isolation-bypass/playbook.md` |
| V05 管理员权限提升 | `_shared/vulnerability_research_units/V05-admin-privilege-escalation/playbook.md` |
| V06 RCE | `_shared/vulnerability_research_units/V06-rce/playbook.md` |
| V07 命令注入 | `_shared/vulnerability_research_units/V07-command-injection/playbook.md` |
| V08 SSTI | `_shared/vulnerability_research_units/V08-ssti/playbook.md` |
| V09 反序列化 | `_shared/vulnerability_research_units/V09-deserialization/playbook.md` |
| V10 任意文件读取 | `_shared/vulnerability_research_units/V10-arbitrary-file-read/playbook.md` |
| V11 任意文件写入 | `_shared/vulnerability_research_units/V11-arbitrary-file-write/playbook.md` |
| V12 路径穿越 | `_shared/vulnerability_research_units/V12-path-traversal/playbook.md` |
| V13 SSRF | `_shared/vulnerability_research_units/V13-ssrf/playbook.md` |
| V14 SQL/NoSQL/ORM 注入 | `_shared/vulnerability_research_units/V14-injection-sql-nosql-orm/playbook.md` |
| V15 XSS | `_shared/vulnerability_research_units/V15-xss/playbook.md` |
| V16 CSRF | `_shared/vulnerability_research_units/V16-csrf-state-change/playbook.md` |
| V17 JWT/Session/Cookie/Token 缺陷 | `_shared/vulnerability_research_units/V17-jwt-session-cookie-token/playbook.md` |
| V18 文件上传高危漏洞 | `_shared/vulnerability_research_units/V18-file-upload-high-risk/playbook.md` |
| V19 原型污染/参数污染/批量赋值 | `_shared/vulnerability_research_units/V19-prototype-parameter-mass-assignment/playbook.md` |
| V20 XXE | `_shared/vulnerability_research_units/V20-xxe/playbook.md` |
| V21 敏感信息泄露 | `_shared/vulnerability_research_units/V21-sensitive-info-disclosure/playbook.md` |
| V22 业务逻辑漏洞 | `_shared/vulnerability_research_units/V22-business-logic/playbook.md` |
| V23 供应链/依赖/插件生态漏洞 | `_shared/vulnerability_research_units/V23-supply-chain-dependency-plugin/playbook.md` |
