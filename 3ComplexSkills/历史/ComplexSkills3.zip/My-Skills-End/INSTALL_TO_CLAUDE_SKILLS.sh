#!/usr/bin/env bash
set -euo pipefail
SKILL_NAME="${1:-My-Skills-End}"
CLAUDE_SKILLS_DIR="${2:-$HOME/.claude/skills}"
ROOT="$(cd "$(dirname "$0")" && pwd)"
TARGET="$CLAUDE_SKILLS_DIR/$SKILL_NAME"

[ -f "$ROOT/SKILL.md" ] || { echo "Root SKILL.md not found: $ROOT" >&2; exit 2; }
[ -d "$ROOT/_shared" ] || { echo "_shared directory not found: $ROOT" >&2; exit 2; }
[ -d "$ROOT/skills" ] || { echo "skills directory not found: $ROOT" >&2; exit 2; }

if [ "${DRY_RUN:-0}" = "1" ]; then
  echo "DRY-RUN single-skill install $ROOT -> $TARGET"
  echo "This preserves SKILL.md, _shared, skills, templates, tests, dashboard, quality gate, and scripts together."
  exit 0
fi

mkdir -p "$CLAUDE_SKILLS_DIR"
RESOLVED_TARGET=""
if [ -e "$TARGET" ]; then RESOLVED_TARGET="$(cd "$TARGET" && pwd)"; fi
if [ -n "$RESOLVED_TARGET" ] && [ "$RESOLVED_TARGET" = "$ROOT" ]; then
  echo "Source is already the target Skill directory: $TARGET"
else
  if [ -e "$TARGET" ]; then
    mv "$TARGET" "$TARGET.backup_$(date +%Y%m%d_%H%M%S)"
  fi
  mkdir -p "$TARGET"
  cp -R "$ROOT"/. "$TARGET"/
  echo "Installed single skill directory: $TARGET"
fi

if [ "${RUN_SELFTEST:-0}" = "1" ]; then
  (cd "$TARGET" && python tools/selftest.py)
fi
