# Report Template - C06-remote-action-risk 远程代码执行 RCE

## Summary
- Candidate ID:
- Template ID: C06-remote-action-risk
- Authorized scope:

## Evidence
- Code evidence:
- Dynamic evidence:
- Negative control:
- Specialized fields:

## Impact
- Affected asset:
- Security impact:
- Boundary:

## Remediation
- Fix the missing server-side enforcement or unsafe sink identified by code evidence.
- Add regression tests for positive, negative, blocked and manual-review replay states.
