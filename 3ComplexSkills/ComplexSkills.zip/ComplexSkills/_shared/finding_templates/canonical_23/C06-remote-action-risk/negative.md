# Negative Controls - C06-remote-action-risk 远程代码执行 RCE

Minimum negative controls:

1. Same route and safe baseline input returns expected authorized/denied behavior.
2. Low-privilege or cross-tenant fixture does not obtain unauthorized impact.
3. Tool warnings without code and dynamic evidence remain `rejected` or `needs_human_review`.
4. Missing authorization scope or state-changing validation requirement becomes `blocked`.
