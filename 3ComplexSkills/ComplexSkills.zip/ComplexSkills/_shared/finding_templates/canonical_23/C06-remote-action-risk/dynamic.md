# Dynamic Validation Boundary - C06-remote-action-risk 远程代码执行 RCE

Allowed: local authorized fixture replay, read-only request/response comparison, schema validation, log review, screenshot/reference collection, and negative-control replay.

Forbidden: third-party probing, state-changing writes, service availability impact, persistence, credential theft, privilege abuse, data exfiltration, or any validation outside the explicitly authorized local project.

A candidate remains `blocked` or `needs_human_review` when the next validation step would exceed these boundaries.
