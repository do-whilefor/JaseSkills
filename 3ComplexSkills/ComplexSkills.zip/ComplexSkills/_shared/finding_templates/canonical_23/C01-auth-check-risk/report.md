# Report Template - C01-auth-check-risk 认证绕过

## Summary
- Candidate ID:
- Template ID: C01-auth-check-risk
- Authorized scope:

## Evidence
- Code evidence:
- Dynamic evidence:
- Negative control:
- Specialized fields:

## Impact
- Affected asset:
- Security impact:
- Boundary:

## Remediation
- Fix the missing server-side enforcement or unsafe sink identified by code evidence.
- Add regression tests for positive, negative, blocked and manual-review replay states.
