# Report Template - C08-template-input-risk 模板注入

## Summary
- Candidate ID:
- Template ID: C08-template-input-risk
- Authorized scope:

## Evidence
- Code evidence:
- Dynamic evidence:
- Negative control:
- Specialized fields:

## Impact
- Affected asset:
- Security impact:
- Boundary:

## Remediation
- Fix the missing server-side enforcement or unsafe sink identified by code evidence.
- Add regression tests for positive, negative, blocked and manual-review replay states.
