# Canonical 23 Template Index

参见 `_shared/template_index.json`。所有模板均限定为本机授权、非破坏性、候选优先、证据驱动。
