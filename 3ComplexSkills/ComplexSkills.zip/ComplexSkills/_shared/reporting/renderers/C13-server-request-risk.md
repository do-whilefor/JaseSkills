# Renderer C13-server-request-risk

This renderer is template-specific. Required evidence fields are loaded from `_shared/finding_templates/canonical_23/C13-server-request-risk/evidence.json`. Generic confirmed reports are forbidden.
