# Renderer C23-dependency-build-risk

This renderer is template-specific. Required evidence fields are loaded from `_shared/finding_templates/canonical_23/C23-dependency-build-risk/evidence.json`. Generic confirmed reports are forbidden.
