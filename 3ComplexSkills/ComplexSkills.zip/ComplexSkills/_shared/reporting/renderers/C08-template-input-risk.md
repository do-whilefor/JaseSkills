# Renderer C08-template-input-risk

This renderer is template-specific. Required evidence fields are loaded from `_shared/finding_templates/canonical_23/C08-template-input-risk/evidence.json`. Generic confirmed reports are forbidden.
