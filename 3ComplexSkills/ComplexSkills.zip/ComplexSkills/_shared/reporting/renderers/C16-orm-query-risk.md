# Renderer C16-orm-query-risk

This renderer is template-specific. Required evidence fields are loaded from `_shared/finding_templates/canonical_23/C16-orm-query-risk/evidence.json`. Generic confirmed reports are forbidden.
