# Renderer C21-cross-origin-risk

This renderer is template-specific. Required evidence fields are loaded from `_shared/finding_templates/canonical_23/C21-cross-origin-risk/evidence.json`. Generic confirmed reports are forbidden.
