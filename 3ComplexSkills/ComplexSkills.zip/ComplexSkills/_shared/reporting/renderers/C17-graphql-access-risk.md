# Renderer C17-graphql-access-risk

This renderer is template-specific. Required evidence fields are loaded from `_shared/finding_templates/canonical_23/C17-graphql-access-risk/evidence.json`. Generic confirmed reports are forbidden.
