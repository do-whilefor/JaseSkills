# Renderer C22-sensitive-data-risk

This renderer is template-specific. Required evidence fields are loaded from `_shared/finding_templates/canonical_23/C22-sensitive-data-risk/evidence.json`. Generic confirmed reports are forbidden.
