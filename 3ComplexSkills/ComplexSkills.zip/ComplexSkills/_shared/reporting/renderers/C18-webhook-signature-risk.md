# Renderer C18-webhook-signature-risk

This renderer is template-specific. Required evidence fields are loaded from `_shared/finding_templates/canonical_23/C18-webhook-signature-risk/evidence.json`. Generic confirmed reports are forbidden.
