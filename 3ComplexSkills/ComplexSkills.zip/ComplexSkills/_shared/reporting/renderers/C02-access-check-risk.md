# Renderer C02-access-check-risk

This renderer is template-specific. Required evidence fields are loaded from `_shared/finding_templates/canonical_23/C02-access-check-risk/evidence.json`. Generic confirmed reports are forbidden.
