# Renderer C05-admin-boundary-risk

This renderer is template-specific. Required evidence fields are loaded from `_shared/finding_templates/canonical_23/C05-admin-boundary-risk/evidence.json`. Generic confirmed reports are forbidden.
