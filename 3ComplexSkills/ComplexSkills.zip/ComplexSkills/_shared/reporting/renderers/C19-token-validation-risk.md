# Renderer C19-token-validation-risk

This renderer is template-specific. Required evidence fields are loaded from `_shared/finding_templates/canonical_23/C19-token-validation-risk/evidence.json`. Generic confirmed reports are forbidden.
