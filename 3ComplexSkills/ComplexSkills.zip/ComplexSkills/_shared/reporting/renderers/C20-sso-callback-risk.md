# Renderer C20-sso-callback-risk

This renderer is template-specific. Required evidence fields are loaded from `_shared/finding_templates/canonical_23/C20-sso-callback-risk/evidence.json`. Generic confirmed reports are forbidden.
