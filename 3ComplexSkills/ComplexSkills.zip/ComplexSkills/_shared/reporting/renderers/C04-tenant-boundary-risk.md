# Renderer C04-tenant-boundary-risk

This renderer is template-specific. Required evidence fields are loaded from `_shared/finding_templates/canonical_23/C04-tenant-boundary-risk/evidence.json`. Generic confirmed reports are forbidden.
