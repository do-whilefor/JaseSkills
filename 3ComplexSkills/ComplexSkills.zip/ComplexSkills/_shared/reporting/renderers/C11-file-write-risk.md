# Renderer C11-file-write-risk

This renderer is template-specific. Required evidence fields are loaded from `_shared/finding_templates/canonical_23/C11-file-write-risk/evidence.json`. Generic confirmed reports are forbidden.
