# Renderer C10-file-read-risk

This renderer is template-specific. Required evidence fields are loaded from `_shared/finding_templates/canonical_23/C10-file-read-risk/evidence.json`. Generic confirmed reports are forbidden.
