# Renderer C12-upload-write-risk

This renderer is template-specific. Required evidence fields are loaded from `_shared/finding_templates/canonical_23/C12-upload-write-risk/evidence.json`. Generic confirmed reports are forbidden.
