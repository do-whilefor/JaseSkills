# Renderer C06-remote-action-risk

This renderer is template-specific. Required evidence fields are loaded from `_shared/finding_templates/canonical_23/C06-remote-action-risk/evidence.json`. Generic confirmed reports are forbidden.
