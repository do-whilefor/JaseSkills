# Renderer C09-object-parse-risk

This renderer is template-specific. Required evidence fields are loaded from `_shared/finding_templates/canonical_23/C09-object-parse-risk/evidence.json`. Generic confirmed reports are forbidden.
