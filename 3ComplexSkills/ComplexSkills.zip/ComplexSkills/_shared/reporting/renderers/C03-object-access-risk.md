# Renderer C03-object-access-risk

This renderer is template-specific. Required evidence fields are loaded from `_shared/finding_templates/canonical_23/C03-object-access-risk/evidence.json`. Generic confirmed reports are forbidden.
