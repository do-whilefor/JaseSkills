# Renderer C01-auth-check-risk

This renderer is template-specific. Required evidence fields are loaded from `_shared/finding_templates/canonical_23/C01-auth-check-risk/evidence.json`. Generic confirmed reports are forbidden.
