# JS15-hash-dedup hash 去重

负责 skill：`skills/05-js-review/SKILL.md`

AST / parser 要求：`sha256 content dedupe`。

输出字段：`dedupe_index[]`。

候选问题点联动：`all`。

进入 manifest 字段：`js_graph.dedupe_index`。

测试样例：`_shared/tests/claim_review/fixtures/js-hash-dedupe.json`。

预期输出：提取结果必须能追踪到 JS source、chunk/hash、source span；若进入问题点候选，必须产生 `candidate_to_manifest_link`。

失败判断：无法追踪 JS -> candidate -> evidence manifest -> quality gate -> report section 时失败。

质量门槛：`QG-JS-chain-required; JS-derived confirmed finding must have candidate_to_manifest_link, original span when sourcemap exists, and template-specific evidence`。

本机授权边界：只分析本机授权项目中的源码、构建产物、sourcemap 和 fixtures；CDN URL 只记录引用，不主动访问第三方。
