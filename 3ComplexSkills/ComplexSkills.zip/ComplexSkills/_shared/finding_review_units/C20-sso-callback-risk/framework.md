# C20 框架笔记

Passport/NextAuth/Auth0/Keycloak/Spring Security/OmniAuth/Django allauth 需映射 provider config 与 callback handler。
