# C20 非破坏性动态验证

仅本机授权回调 fixture。记录合法 callback、缺失 state、错误 nonce、非 allowlist redirect_uri、相对路径 redirect 的响应差异。禁止对真实 IdP 发起登录轰炸。
