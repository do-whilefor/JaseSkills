# C20 误报排除

仅存在 oauth 字符串、仅文档配置、state 由框架强制校验且有证据、redirect 仅内部相对安全路径，不得 confirmed。
