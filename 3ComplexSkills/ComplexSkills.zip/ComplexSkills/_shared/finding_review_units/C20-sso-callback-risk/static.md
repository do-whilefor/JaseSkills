# C20 OAuth/SSO/callback/redirect_uri 静态规则

检查 redirect_uri allowlist、state/nonce 校验、PKCE、issuer/audience、SAML ACS、open redirect 链路。候选条件：redirect_uri 通配、state 可选、callback next 参数未限制、issuer/audience 未校验。
