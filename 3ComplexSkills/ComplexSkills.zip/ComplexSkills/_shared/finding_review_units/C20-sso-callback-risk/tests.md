# C20 回放样例

POS：callback 接受任意 redirect_uri 或缺失 state。NEG：错误 state 400。BLK：真实 IdP 外部域。REV：托管 SDK 隐藏校验逻辑。
