# C18-webhook-signature-risk dedicated research unit

Purpose: provide a dedicated review route for `C18-webhook-signature-risk` instead of dispatching it into generic business-logic review.

Rules:
- Generate candidates only from local authorized code graph, JS audit, schema, route, and capture artifacts.
- Do not confirm from template match alone.
- Require code evidence, non-state-changing local dynamic evidence, negative control, specialized fields, artifact hashes, and quality gate score >= 85.
- If validation requires third-party probing, state-changing mutation, privilege abuse, or live credential misuse, set `validation_blocked` or `needs_human_review`.
