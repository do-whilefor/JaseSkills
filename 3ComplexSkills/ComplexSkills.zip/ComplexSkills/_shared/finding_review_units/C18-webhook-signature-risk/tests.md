# C18 回放样例

POS：unsigned webhook accepted。NEG：tampered body rejected。BLK：真实外部 webhook endpoint。REV：签名校验在 SDK 内但源码不可见。
