# C18 框架笔记

Express body-parser 顺序、Next.js raw body、Rails request.raw_post、Laravel middleware、Stripe/GitHub/GitLab 签名头需要分别记录。
