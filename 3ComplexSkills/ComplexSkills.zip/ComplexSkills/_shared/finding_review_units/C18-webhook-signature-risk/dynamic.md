# C18 非破坏性动态验证

仅对本机 webhook fixture 发送无副作用 ping/test event。必须记录 signed/unsigned/tampered/expired 四类请求摘要，禁止触发真实业务动作。
