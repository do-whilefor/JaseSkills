# C18 误报排除

路由名包含 webhook 但进入统一验签 middleware；测试 mock；仅第三方 SDK 自动验签且有代码证据时不得 confirmed。
