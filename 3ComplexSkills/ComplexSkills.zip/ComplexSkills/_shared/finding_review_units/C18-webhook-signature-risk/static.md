# C18 Webhook 签名绕过静态规则

必须定位 raw body、HMAC/签名算法、timestamp/replay window、secret source、失败分支。候选条件：未校验签名、使用 parsed body 导致签名不一致、允许空签名、timestamp 不校验。
