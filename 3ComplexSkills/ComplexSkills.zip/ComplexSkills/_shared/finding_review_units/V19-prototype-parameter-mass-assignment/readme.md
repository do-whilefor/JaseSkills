
# V19 原型污染/参数污染/批量赋值 研究单元

## 定义

本单元只在本机授权项目中识别、映射和验证 `原型污染/参数污染/批量赋值` 候选。它不对第三方目标生成越界测试步骤，不执行破坏性动作，不把工具告警直接视为问题点。

## 适用场景

- 代码、路由、配置、依赖、JS 运行时或动态业务流中出现与 `原型污染/参数污染/批量赋值` 相关的安全边界疑点。
- 候选可映射到 route、handler、parameter、actor、asset、trust_boundary、guard 或 sink。

## 边界

- 无代码证据：最高停在 `discovered` 或 `needs_human_review`。
- 无动态证据：最高停在 `validation_planned` 或 `validation_blocked`。
- 无负样本：不得进入 `quality_gate_passed`。
- 会导致数据删除、拒绝服务、大规模压测、真实第三方数据访问时必须 `unsafe_to_execute`。
