
# NON_DESTRUCTIVE_BOUNDARY: JWT/Session/Cookie/Token 缺陷

- 只使用本机授权服务、本机测试账号、本机测试租户、本机测试对象。
- 不删除数据、不覆盖真实文件、不触发大规模请求、不测试拒绝服务。
- 写入类、权限变更类、RCE/命令执行类、SSRF 类只能做最小化、无害、可回滚或离线证明。
- 涉及第三方网络、云 metadata、内网探测时只允许记录候选风险和阻塞原因，不执行真实探测。
- 无法保证非破坏性时，状态必须为 `validation_blocked` 或 `unsafe_to_execute`。
