
# 报告模板：SQL/NoSQL/ORM 注入

## 摘要

- 候选 ID：`{candidate_id}`
- 状态：`{state}`
- 风险：`{risk}`
- Quality Gate：`{quality_gate_score.total}`

## 证据

- 代码位置：`{source_file}:{source_line}`
- 路由：`{method} {route}`
- 参数：`{parameter}`
- 认证上下文：`{auth_context}`
- 租户上下文：`{tenant_context}`
- 请求/响应摘要：`{request_summary}` / `{response_summary}`
- 负样本：`{negative_control}`
- 复现次数：`{reproduction_count}`

## 影响

`{impact}`

## 误报排除

`{false_positive_notes}`

## 修复建议

根据 `SQL/NoSQL/ORM 注入` 类型，在对应 guard、输入校验、权限/租户绑定、路径规范化、参数化查询、配置或依赖治理位置修复。修复后必须增加回归测试。
