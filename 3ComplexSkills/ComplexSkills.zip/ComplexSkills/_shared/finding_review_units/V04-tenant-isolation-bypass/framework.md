
# FRAMEWORK_NOTES: 租户隔离绕过

## JavaScript / TypeScript

- Express/Koa/Fastify/Nest/Next/Nuxt：检查路由中间件、guard、decorator、API route、server action、edge handler、fetch wrapper 和 bundle/source map 回流。

## Python

- Django/Flask/FastAPI：检查 decorator、dependency、permission class、serializer/ORM 查询、path/file/url 处理。

## Java

- Spring：检查 SecurityFilterChain、method security、controller、service、repository、SpEL、template、XML/parser 配置。

## PHP

- Laravel/Symfony：检查 middleware、policy、request validation、mass assignment、filesystem、view/render、XML/parser 配置。

## Ruby

- Rails：检查 before_action、policy、strong parameters、ActiveStorage、template/render、YAML/XML 解析。

## Go

- Gin/Echo/Fiber：检查 middleware 顺序、context user、path/file/url、exec、template、database/sql 参数化。

## Rust

- Axum/Actix/Rocket：检查 extractor、middleware、state、path/file/url、template、command、serde 边界。
