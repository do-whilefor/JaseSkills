
# TEST_CASES: XXE

## 正样本

- 本机授权项目中存在 route → handler → source → sink 链路，且 guard 缺失或位置错误。
- 能构造正常样本、异常样本、负样本，并进入 `validation_planned`。

## 负样本

- 参数名相似但没有进入 sink。
- 后端有明确 guard 或安全封装。
- 只有工具告警或前端暴露。

## 模糊样本

- 框架识别混淆、测试环境配置、mock 数据、source map 暴露但服务端废弃接口。

## expected_status

- 正样本：`validation_planned`，不得直接 `confirmed`。
- 负样本：`rejected`。
- 环境不足：`validation_blocked`。
