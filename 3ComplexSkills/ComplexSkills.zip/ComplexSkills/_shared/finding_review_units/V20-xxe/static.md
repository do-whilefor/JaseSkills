
# STATIC_RULES: XXE

## 静态候选生成规则

候选必须同时满足：

1. 命中 source 或入口：路由参数、query/body、header、cookie、上传文件、source map 暴露接口、配置项、队列消息或 webhook payload。
2. 可追踪到 sink 或安全边界：XML/SOAP/SAML/SVG/Office/RSS parser, DTD/external entity disabled check。
3. 缺少或疑似绕过 guard：认证、授权、租户过滤、输入校验、路径规范化、schema 校验、CSRF 检查、参数化查询等。
4. 能写入 `source_file`、`source_line`、`route`、`method`、`parameter`。

## 不得晋级的情况

- 只有危险函数存在但参数不可控。
- 只有参数名相似但后端未使用。
- 只有测试代码、注释或 README 中的描述。
- 只有前端暴露接口但后端有明确鉴权。
