# C21 回放样例

POS：evil Origin 被反射且 ACAC true。NEG：evil Origin 无 ACAO。BLK：第三方目标。REV：只发现配置片段未映射运行环境。
