# C21 非破坏性动态验证

仅本机 API。分别发送可信 Origin、恶意 Origin、null Origin、无凭证/带凭证请求，记录 ACAO/ACAC/Vary/status。不得读取真实用户数据。
