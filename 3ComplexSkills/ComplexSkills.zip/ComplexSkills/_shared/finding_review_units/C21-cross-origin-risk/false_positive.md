# C21 误报排除

ACAO * 但无 credentials 且无敏感响应；静态资源 CORS；开发配置未进入部署路径；仅预检成功但实际接口拒绝，不得 confirmed。
