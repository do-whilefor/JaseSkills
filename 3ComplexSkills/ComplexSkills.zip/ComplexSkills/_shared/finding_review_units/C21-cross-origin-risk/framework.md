# C21 框架笔记

Express cors、Spring CorsConfiguration、Django CORS_HEADERS、Rails rack-cors、Nginx add_header、S3/CloudFront 需分别记录配置来源。
