# C21 CORS 重点误配置静态规则

检查 ACAO 反射、ACAC true、Origin allowlist、credentialed API、Vary Origin、preflight。候选条件：任意 Origin + credentials；正则 allowlist 可绕；内部/管理 API 允许跨域凭证。
