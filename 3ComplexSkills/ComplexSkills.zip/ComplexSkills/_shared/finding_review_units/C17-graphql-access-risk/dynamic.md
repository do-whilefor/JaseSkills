# C17 非破坏性动态验证

仅在本机授权环境对 `/graphql` 发送查询型 operation，不执行 mutation。必须记录角色 A/B、tenant A/B、operationName、variables、响应字段差异、错误码和 negative control。禁止批量压测和资源消耗型深度查询。
