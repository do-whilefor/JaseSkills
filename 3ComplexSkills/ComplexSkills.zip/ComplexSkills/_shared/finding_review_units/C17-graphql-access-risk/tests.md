# C17 回放样例

POS：resolver 返回 `invoice(id)` 且无 owner/tenant guard。NEG：resolver 使用 context.user + tenant filter。BLK：目标非 localhost。REV：只有 persisted hash 无 resolver 源码。
