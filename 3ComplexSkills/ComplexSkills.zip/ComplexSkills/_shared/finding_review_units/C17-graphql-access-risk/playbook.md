# 验证剧本

1. 绑定本机授权 scope。2. 生成 candidate。3. 采集代码证据。4. 执行最小非破坏性动态验证。5. 执行 negative control。6. 写入 manifest。7. 跑 quality gate。
