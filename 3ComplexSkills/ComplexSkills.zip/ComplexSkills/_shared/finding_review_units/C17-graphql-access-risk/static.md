# C17 GraphQL 权限绕过静态规则

必须定位 schema/resolver/context/auth middleware。候选条件：resolver 缺少 auth guard；operation/fragment/persisted query 可访问高价值对象；introspection 暴露敏感 schema 且环境非开发。误报排除：仅存在 GraphQL client 字符串、仅开发测试 schema、resolver 统一走全局 guard 且有代码证据。
