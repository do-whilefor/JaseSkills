# 非破坏性边界

只允许本机授权项目、localhost、fixture、GET/HEAD 或明确无副作用请求。禁止外部目标、批量压测、真实数据修改。
