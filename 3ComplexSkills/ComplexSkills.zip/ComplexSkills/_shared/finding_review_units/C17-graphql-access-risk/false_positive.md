# C17 误报排除

没有 resolver 代码证据、没有对象/角色差异、只有 introspection 字符串、只有前端 fragment 而无后端 schema 映射，均不得 confirmed。
