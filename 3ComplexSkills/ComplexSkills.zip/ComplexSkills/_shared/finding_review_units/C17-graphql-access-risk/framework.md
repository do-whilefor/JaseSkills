# C17 框架笔记

Apollo/NestJS Yoga/Graphene/HotChocolate/Spring GraphQL 均需检查 context user 注入、field-level guard、DataLoader tenant filter、persisted query allowlist。
