# VULNERABILITY_CHAIN_HUNTING

链式风险只能生成候选链，不能因链条“看起来可能”确认问题点。每个节点必须拆分为独立证据节点。

| ID | 链路 | 独立证据节点 |
|---|---|---|
| CH01 | 信息泄露 → 认证绕过 | sensitive_info_disclosure, auth_bypass |
| CH02 | source map → 隐藏接口 → IDOR | sourcemap_endpoint, hidden_route, idor_bola |
| CH03 | 前端权限判断 → 后端鉴权缺失 | frontend_guard, backend_guard_missing |
| CH04 | 文件上传 → 路径穿越 → 任意写入 | file_upload, path_traversal, arbitrary_file_write |
| CH05 | 任意写入 → 模板覆盖 → RCE 候选 | arbitrary_file_write, template_override, rce_candidate |
| CH06 | SSRF → 内网 metadata 风险候选 | ssrf_candidate, metadata_boundary_blocked |
| CH07 | 低权限接口 → role 修改 → 管理员提升 | low_privilege_endpoint, role_update, admin_escalation |
| CH08 | 邀请流程 → 租户加入 → 租户数据越权 | invite_flow, tenant_join, tenant_data_access |
| CH09 | Webhook → SSRF → 敏感响应泄露 | webhook_fetch, ssrf, sensitive_response |
| CH10 | 依赖问题点 → 项目可达调用点 → 实际影响 | dependency_cve, reachable_callsite, impact_evidence |
