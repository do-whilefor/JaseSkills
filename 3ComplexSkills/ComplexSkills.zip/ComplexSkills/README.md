# ComplexSkills

This directory is a single installable Skill package for local, authorized project review. `SKILL.md` is the root entry. `skills/` contains routed internal modules. `_shared/` contains the knowledge base, finding templates, schemas, evidence contracts, quality gates, replay fixtures, and dashboard support.

## Preservation policy

- Keep `_shared/knowledge/` intact. Knowledge entries are hypothesis sources only; they are not direct finding evidence.
- Keep `_shared/finding_templates/` intact. These are the canonical finding templates and report/evidence requirements.
- Keep executable overlays outside the canonical template tree in `_shared/executable_template_overlays/`.

## Authorized-use boundary

Use only on local projects, local labs, local fixtures, or targets where explicit authorization exists. The package is designed for read-only review and non-state-changing evidence collection. It should not be used for unauthorized probing, state-changing tests without rollback data, load testing, credential misuse, concealment, or data extraction.

## Browser/MCP compatibility note

Some Playwright/MCP page-code channels do not expose `dynamic import()`, `require()`, Node `fs`, or direct local file writes. The package now treats those APIs as unavailable in page context. JSON evidence should be written by Python-side scripts such as `skills/06-browser-capture/scripts/pw_capture_local.py` or imported from page-level network, snapshot, console, and screenshot artifacts.

## Install on Windows

Run from the extracted package root:

```powershell
Set-ExecutionPolicy -Scope Process Bypass -Force
.\install.ps1 -SkillName ComplexSkills -RunSelfTest
```

## Install on Bash-compatible shells

```bash
./install.sh ComplexSkills
```

## Verify package health

Run from the package root. On Windows, use `py -3` or `python`; examples below use `python`.

```powershell
python tools/runtime_check.py --out _audit_outputs/runtime_readiness.json
python tools/selftest.py --out _audit_outputs/selftest_result.json
python _shared/tests/smoke/anti_lazy_browser_gate_smoke_test.py
python _shared/tests/smoke/top_tier_completion_gate_smoke_test.py
python _shared/tests/regression/top_tier_regression_harness.py
```

## Claim rule

A finding remains `candidate`, `likely`, `needs_manual_review`, or `runtime_blocked` until target-specific evidence exists. `confirmed` requires validated evidence manifest entries, code evidence, runtime evidence where applicable, role/tenant context, positive and negative controls, variant coverage, and a passing quality gate.

## Key files

- `SKILL.md`
- `runtime.md`
- `_shared/knowledge/`
- `_shared/finding_templates/`
- `_shared/executable_template_overlays/executable_templates_index.json`
- `_shared/quality/final_claim_guard.py`
- `skills/03-code-map/scripts/semantic_graph.py`
- `skills/07-finding-engine/scripts/review_plan.py`
- `dashboard/index.html`

## One-command local pipeline

```powershell
python tools/local_pipeline.py C:\path\to\local-authorized-project --out-dir _audit_outputs/pipeline
```

The pipeline produces inventory, code graph, JS review output, exposure surface records, candidates, and review plans. It intentionally blocks confirmed claims until executed evidence and quality gates exist.
