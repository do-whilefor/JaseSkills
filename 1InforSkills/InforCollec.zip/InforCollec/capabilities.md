# 信息暴露面审计 Skills 能力索引

必须先从 `00-core` 开始。除非用户明确要求单项能力，不要直接从子 Skill 开始。

| Skill / 文件 | 用途 | 何时使用 | 输出状态 |
|---|---|---|---|
| `00-core` | 总控调度、任务分类、三档路径、跨 Skill 交接 | 任意执行型信息暴露面审计开始 | 调度记录 |
| `01-scope` | 根目录、运行方式、端口、Base URL、账号角色、禁止范围 | 审计前置 | 输入确认 |
| `02-run` | 本机运行态入口、端口、服务、文档、health、metrics | 有 Base URL 或端口 | 入口候选 |
| `03-code` | 源码、路由、JS、配置、依赖、部署、包产物候选 | 需要从代码/文件找候选 | 静态候选 |
| `04-verify` | HTTP/协议非破坏动态验证 | 有候选 URL/端口/协议入口 | 动态证据 |
| `05-roles` | 角色差异、cookie、localStorage、sessionStorage、IndexedDB、Cache Storage | 有授权账号或浏览器状态 | 角色/浏览器证据 |
| `06-artifacts` | 补充检查、二轮反思、容器、缓存、错误面、文档影子 | 第一轮后或专家路径 | 新增候选/反思 |
| `07-qg` | 脱敏、QG、不可报告、报告 | 交付前 | 报告/阶段报告 |
| `08-review` | Skills 自审、触发路由压测、真实性校验、回归测试 | 审查或维护 Skills 包 | 审查结果/修复任务 |

## 核心硬规则

- 静态候选不是发现。
- 工具输出不是结论。
- 无动态证据不输出确定结论。
- 无账号不输出角色差异。
- 需保护信息必须脱敏。
- 文档、模板、矩阵、示例不等于实现。
- parser/backend/runtime 不可用时，必须降级输出。

## 能力绑定

| 能力 | 文件 | 当前实现等级 | 限制 |
|---|---|---|---|
| JS 资产候选采集 | `scripts/js_audit.py`, `detectors/js_coverage.yaml`, `tests/test_js_audit.py` | 候选级实现 | 不是完整 AST/dataflow；需 parser backend 和动态验证 |
| JS endpoint 候选 | `scripts/js_ast.mjs`, `tests/test_js_ast.py`, `tests/test_js_strict.py` | 有 AST walk；backend 缺失时显式 lexical fallback | 不等于完整 Babel/TS 数据流 |
| 代码暴露面采集 | `scripts/code_inv.py`, `scripts/codegraph.py`, `tests/test_code_inv.py`, `tests/test_codegraph.py` | Python AST + 多语言 lexical graph | 不执行项目代码，不证明发现 |
| 配置与依赖采集 | `scripts/config_inv.py`, `tests/test_config_inv.py` | 本地文件候选采集 | 不联网查 CVE，不执行依赖脚本 |
| 前端 manifest / service worker 展开 | `scripts/manifest_expand.py`, `tests/test_manifest_expand.py` | 本地工件级实现 | 不下载 CDN 历史版本，不恢复远端 sourcemap |
| 信息面归一化 | `schemas/surface.json`, `scripts/normalize.py`, `tests/test_normalize.py` | 统一字段与候选路由 | 不是确认发现 detector |
| source/sink 候选 | `scripts/taint.py`, `tests/test_taint.py` | 窗口级候选；全部 `needs_review` | 不能宣传为确认发现 |
| C01-C05 访问控制候选 | `detectors/access.py` | 候选 detector | 无 role/tenant replay 时不能 promoted |
| C06-C30 高影响入口候选 | `detectors/impact.py`, `tests/test_impact.py` | 高影响入口路由；默认 needs_review | 不是完整 AST/source-sink detector |
| Parser backend readiness | `scripts/parser_check.py` | 可用性检查 | 不安装依赖，不代表完整 parser ready |
| Runtime readiness | `scripts/runtime_check.py` | 本地依赖/文件/URL 检查 | 不启动服务，不探测外部目标 |
| 角色/租户运行态契约 | `scripts/har_matrix.mjs`, `schemas/runtime.json`, `tests/test_role_matrix.py` | 无 Playwright 时输出 contract-only | 不等于 HAR 已采集 |
| WebSocket 只读契约 | `scripts/ws_capture.mjs`, `tests/test_ws.py` | 安全输出契约 | 不等于 WS 权限绕过验证 |
| Evidence Manifest | `scripts/to_manifest.py`, `schemas/evidence.json` | 证据索引 | 不自动确认 finding |
| JSONL 质量门 | `scripts/qg_jsonl.py`, `schemas/finding_chain.json`, `tests/test_qg_jsonl.py`, `tests/test_qg_linkage.py` | 字段与 manifest linkage 门禁 | 不替代人工复核 |
| 模板索引 | `manifests/templates.json`, `tests/test_templates.py` | 全模板索引 | 模板不等于实现 |
| 知识索引与人工复核 | `manifests/knowledge.json`, `knowledge/`, `human_review/queue.jsonl` | 知识库保留与复核入口 | conflict/needs_review 不自动 promoted |
| Dashboard | `dashboard/build.py` | 读取 selftest 产物生成摘要 | 不是发现确认面板 |
| 发布清理 | `scripts/clean.sh`, `tests/test_clean.py` | 清除缓存和陈旧 selftest | 不得删除 `knowledge/`、`templates/` |

## 关键文档

- `docs/routing.md`
- `docs/triggers.md`
- `docs/execution.md`
- `docs/tooling.md`
- `docs/quality.md`
- `docs/evidence.md`
- `docs/no_hallucination.md`
- `docs/failures.md`
- `docs/fidelity.md`
- `docs/mirror_rules.md`

## 信息收集增强能力绑定

| 能力 | 文件 | 当前实现等级 | 限制 |
|---|---|---|---|
| 隐藏信息候选挖掘 | `scripts/hidden_miner.py`, `tests/test_hidden_miner.py`, `rules/hidden.yaml`, `templates/hidden_evidence.md` | 本机只读候选级实现 | 不联网、不验证发现、不输出完整 secret；需要动态验证与 QG |
| API 规格深度盘点 | `scripts/api_inv.py`, `tests/test_api_inv.py`, `templates/api_inv.md` | OpenAPI/Swagger/Postman/GraphQL/proto 静态候选 | YAML 为 best-effort；不做字段高频枚举或 introspection |
| 40 项覆盖面自审 | `scripts/coverage_audit.py`, `tests/test_coverage.py`, `templates/audit_report.md` | 文件/脚本/测试/JSONL 信号绑定审计 | 自审只证明包内能力绑定，不证明目标项目已被完整覆盖 |

新增脚本必须与 `README.md`、`capabilities.md`、`manifests/package_manifest.json`、`templates/`、`tests/` 保持一致。若脚本、测试或模板缺失，对应能力必须标记为 `partial`、`missing` 或 `unverifiable`。
