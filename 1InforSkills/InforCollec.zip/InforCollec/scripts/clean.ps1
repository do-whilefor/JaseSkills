param([string]$Root = ".")
$script = Join-Path $PSScriptRoot "clean.py"
py -3 $script $Root
exit $LASTEXITCODE
