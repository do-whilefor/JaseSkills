#!/usr/bin/env python3
"""Runtime readiness checker for the Skills package.

It checks local tool availability and safe scope defaults. It does not start
services, install browsers, or probe external hosts.
"""
from __future__ import annotations
import argparse, json, os, shutil, subprocess
from datetime import datetime, timezone
from pathlib import Path

def tool(name, args=None):
    exe=shutil.which(name)
    if not exe: return {'available':False,'reason':'not_on_path'}
    if not args: return {'available':True,'path':exe}
    try:
        r=subprocess.run([name]+args,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=5)
        return {'available':r.returncode==0,'path':exe,'returncode':r.returncode,'version':(r.stdout or '').strip().split('\n')[0][:200]}
    except Exception as e: return {'available':False,'path':exe,'reason':type(e).__name__+': '+str(e)}

def main():
    ap=argparse.ArgumentParser(description='Check local runtime readiness without installing or probing targets.')
    ap.add_argument('--project-root', default='.')
    ap.add_argument('--base-url', action='append', default=[])
    ap.add_argument('--out', default=None)
    args=ap.parse_args(); root=Path(args.project_root).resolve()
    urls=[]
    for u in args.base_url:
        ok=u.startswith(('http://localhost','http://127.0.0.1','https://localhost','https://127.0.0.1'))
        urls.append({'url':u,'default_local_allowed':ok,'note':'Non-local hosts require explicit written authorization and allow-host flags.' if not ok else 'local default allowed'})
    checks={
      'python': tool('python',['--version']),
      'py_launcher': tool('py',['-3','--version']),
      'node': tool('node',['--version']),
      'npm': tool('npm',['--version']),
      'curl': tool('curl',['--version']),
      'jq': tool('jq',['--version']),
      'git': tool('git',['--version']),
      'docker': tool('docker',['--version']),
      'bash': tool('bash',['--version']),
      'playwright_import': {'available': False, 'reason':'checked by parser_check.py as playwright_node'},
      'burp_proxy_env': {'available': bool(os.environ.get('BURP_PROXY') or os.environ.get('HTTP_PROXY') or os.environ.get('HTTPS_PROXY')), 'note':'Presence only; not proof that Burp is running or authorized.'}
    }
    required_files=['README.md','capabilities.md','schemas/evidence.json','schemas/asset_ledger.json','schemas/surface.json','schemas/runtime.json','schemas/finding_chain.json','scripts/qg_check.py','scripts/qg_jsonl.py','scripts/to_manifest.py','scripts/js_ast.mjs','scripts/codegraph.py','scripts/taint.py','scripts/har_matrix.mjs','scripts/ws_capture.mjs','detectors/access.py','dashboard/build.py']
    file_checks={f:(root/f).exists() for f in required_files}
    report={'schema_version':'package-schema','generated_at':datetime.now(timezone.utc).isoformat(),'project_root':str(root),'base_url_checks':urls,'tool_checks':checks,'required_package_files':file_checks,'status':'PASS' if all(file_checks.values()) else 'FAIL'}
    text=json.dumps(report,ensure_ascii=False,indent=2)
    if args.out: Path(args.out).write_text(text,encoding='utf-8')
    print(text)
    return 0 if report['status']=='PASS' else 2
if __name__=='__main__': raise SystemExit(main())
