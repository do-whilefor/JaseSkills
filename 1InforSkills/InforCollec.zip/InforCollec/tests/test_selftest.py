from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def test_selftest_runner_syntax_and_key_files_exist():
    shell = (ROOT/'scripts/selftest.sh').read_text(encoding='utf-8')
    assert 'selftest_step.py' in shell
    source = (ROOT/'scripts/selftest_step.py').read_text(encoding='utf-8')
    compile(source, str(ROOT/'scripts/selftest_step.py'), 'exec')
    assert (ROOT/'detectors/impact.py').exists()
