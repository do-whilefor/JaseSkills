# 覆盖率自评

当前是“设计映射覆盖”，不是对任何真实项目的实际覆盖承诺。真实项目覆盖率取决于服务是否运行、账号是否可用、工具是否存在、授权范围是否明确。

| 原文能力 | 设计覆盖 | 主要位置 |
|---|---|---|
| 授权边界 | 已覆盖 | 00/01/07/tooling-contract |
| 输入确认 | 已覆盖 | 01 |
| 四线交叉 | 已覆盖 | 00/03/04/05/07 |
| 资产账本 | 已覆盖 | templates/asset_ledger.md |
| 运行态入口 | 已覆盖 | 02 |
| 代码驱动路由 | 已覆盖 | 03/route_artifact.py |
| 动态验证 | 已覆盖 | 04/probe_safe.sh |
| 信息类型分类 | 已覆盖 | reverse_check.md |
| 小众偏门信息面 | 已覆盖 | 06/second_pass.md |
| 部署信息 | 修复后覆盖 | deploy_check.md/deploy_inv.sh |
| 包产物 | 修复后覆盖 | package_inv.py |
| 协议差异 | 修复后覆盖 | protocol_check.md |
| 三轮反思 | 已覆盖 | 06/07/reflection.md |
| 证据标准 | 已覆盖 | finding_detail.md |
| 最终报告 | 已覆盖 | final_report.md |
| 质量门槛 | 已覆盖 | 07/qg_find.py |

剩余非满分原因：真实浏览器 MCP 依赖用户环境；Docker/Kubernetes/CI/CD 运行态权限不一定存在；gRPC/RPC 深度验证需要具体客户端或 schema；QG 脚本只能做结构化评分，不能替代人工事实判断。
