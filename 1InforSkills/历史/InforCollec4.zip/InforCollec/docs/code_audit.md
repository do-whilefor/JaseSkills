# InforCollec code audit notes

## 修复项

- 根目录从 `Info-End` 改为 `InforCollec`，并保留 Skill 必需的 `SKILL.md`。
- 保留 `knowledge/` 知识库与 `templates/` 漏洞/报告模板内容；模板索引已同步到新文件名。
- 将长文件名、带连字符的工具脚本名、长文档名重命名为短且可识别用途的名称；完整映射见 `manifests/rename_map.json`。
- 修复 `run.py` 的 `sys.path` 优先级，避免短文件名重命名后 `scripts/manifest.py` 与 `reports/manifest.py` 等同名模块冲突。
- 修复质量门 `coverage_gate` 对纯后端/纯 Python 项目误判缺少 `frontend-js` 的问题，改为按项目实际证据与扫描样本动态要求覆盖区段。
- 修复 `scripts/js_ast.mjs` 中重复输出键的问题。
- 清理运行缓存、`__pycache__`、`.pytest_cache` 与编译产物，避免打包冗余。

## 验证项

- `python -m compileall -q .` 通过。
- JSON/JSONL 文件解析通过。
- `python run.py --input tests/fixtures/python_app ...` 通过，输出 `collection-run.json` 状态为 `PASS`。
- `node scripts/js_ast.mjs tests/fixtures/js_ast_app --strict-ast` 通过。
- `bash tests/p0_acceptance.sh /tmp/p0_acceptance_out` 通过。
- `python scripts/runtime_check.py --project-root .` 通过。
- `python scripts/selftest_step.py --root . --outdir /tmp/selftest_step` 通过。

## 保留说明

- `SKILL.md`、`README.md`、`package.json`、`pyproject.toml`、`requirements.txt` 以及测试 fixture 中的 `package.json`、`Dockerfile`、`go.mod` 等生态标准文件名未强制改名，因为这些文件名本身就是运行时/扫描器识别语义的一部分。
