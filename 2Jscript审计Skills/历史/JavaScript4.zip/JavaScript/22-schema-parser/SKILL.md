# 22 JS Framework and Schema Deep Parser

## Trigger
Use when JS audit needs AST wrapper resolution, sourcemap reconstruction, framework build artifact parsing, schema alignment, service worker cache review, CDN history candidate enumeration, or hidden feature signal extraction.

## Execution
Run these scripts in order after collection/analyze:

- `scripts/wrapper_resolve.py`
- `scripts/sourcemap_recon.py`
- `scripts/build_parser.py`
- `scripts/schema_align.py`
- `scripts/sw_cache.py`
- `scripts/cdn_assets.py`
- `scripts/hidden_features.py`
- `scripts/flow_templates.py`

## Evidence standard
All outputs are candidate-only until cross-linked with AST, HAR, browser replay, backend acceptance, and role/tenant evidence. Schema-only fields are hidden parameter candidates, not backend-accepted parameters.
