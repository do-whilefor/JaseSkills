# Candidate Vulnerability

编号：
类型：
代码证据：
触发入口：
Source：
Sink：
中间传播：
权限/校验情况：
最小权限：
影响假设：
非破坏性验证：
反证方法：
优先级：
不可报告原因：
