@echo off
setlocal
cd /d "%~dp0\..\.."
node scripts\run.mjs windows:validate
exit /b %ERRORLEVEL%
