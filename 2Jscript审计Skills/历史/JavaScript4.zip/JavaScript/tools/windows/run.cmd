@echo off
setlocal
cd /d "%~dp0\..\.."
node scripts\run.mjs %*
exit /b %ERRORLEVEL%
