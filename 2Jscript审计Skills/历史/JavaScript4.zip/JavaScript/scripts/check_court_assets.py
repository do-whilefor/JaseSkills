#!/usr/bin/env python3
from __future__ import annotations
import json, sys, subprocess
from pathlib import Path
root = Path(sys.argv[1] if len(sys.argv)>1 else '.').resolve()
required = [
 '14-evidence-court/SKILL.md',
 'scripts/evidence_court.py',
 'scripts/check_court_assets.py',
 'schemas/evidence-court.schema.json',
 'templates/evidence_court.md',
 'docs/evidence_court.md',
 'knowledge/court_rules.md',
 'data/court_prior_trial.json',
 'data/court_incidents.json',
 'data/court_pseudo_caps.json',
 'data/court_miss_risks.json',
 'data/court_engineering.json',
 'data/court_score_rules.json',
 'data/court_p0.json',
 'data/court_findings.json',
 'templates/evidence_court.md',
]
errors=[]
for rel in required:
    if not (root/rel).exists(): errors.append(f'missing: {rel}')
# cardinality checks
checks = {
 'data/court_incidents.json':20,
 'data/court_pseudo_caps.json':10,
 'data/court_miss_risks.json':30,
 'data/court_engineering.json':10,
 'data/court_p0.json':10,
}
for rel, min_items in checks.items():
    if (root/rel).exists():
        try:
            data=json.loads((root/rel).read_text(encoding='utf-8'))
            if len(data) < min_items: errors.append(f'{rel}: expected >= {min_items}, got {len(data)}')
        except Exception as e:
            errors.append(f'{rel}: invalid json: {e}')
if not errors:
    proc=subprocess.run([sys.executable, str(root/'scripts/evidence_court.py'), str(root)], text=True, capture_output=True)
    if proc.returncode != 0:
        errors.append('final_evidence_court_audit failed: ' + proc.stdout + proc.stderr)
print(json.dumps({'ok': not errors, 'errors': errors}, ensure_ascii=False, indent=2))
raise SystemExit(1 if errors else 0)
