#!/usr/bin/env python3
from __future__ import annotations
import json, sys
from pathlib import Path
root=Path(sys.argv[1] if len(sys.argv)>1 else '.').resolve()
required={
 'data/collection_points.json':20,
 'data/audit_caps.json':30,
 'data/severe_chains.json':30,
 'data/linkage_matrix.json':10,
 'data/script_inventory.json':15,
 'templates/skill_review.md':1,
 'schemas/skill-review.schema.json':1,
 '12-skill-review/SKILL.md':1,
 'knowledge/review_checklist.md':1,
 'data/second_collection.json':30,
 'data/second_caps.json':20,
 'data/second_severe_chains.json':25,
 'data/second_unusual_points.json':40,
 'scripts/second_review.py':1,
 '13-second-review/SKILL.md':1,
}

errors=[]
for rel,min_count in required.items():
    p=root/rel
    if not p.exists():
        errors.append(f'missing: {rel}'); continue
    if p.suffix=='.json':
        data=json.loads(p.read_text(encoding='utf-8'))
        count=len(data) if isinstance(data,list) else 1
        if count < min_count: errors.append(f'too few entries: {rel} has {count}, need {min_count}')
    elif not p.read_text(encoding='utf-8').strip():
        errors.append(f'empty: {rel}')
print(json.dumps({'ok':not errors,'errors':errors}, ensure_ascii=False, indent=2))
raise SystemExit(1 if errors else 0)
