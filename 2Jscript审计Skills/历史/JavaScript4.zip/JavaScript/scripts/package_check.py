#!/usr/bin/env python3
from __future__ import annotations
import json, re, sys
from pathlib import Path

root = Path(sys.argv[1] if len(sys.argv) > 1 else '.').resolve()
errors: list[str] = []

for d in sorted(root.glob('[0-9][0-9]-*')):
    if d.is_dir() and not (d / 'SKILL.md').exists():
        errors.append(f'missing SKILL.md: {d.relative_to(root)}')

for p in root.rglob('*'):
    rel = p.relative_to(root).as_posix()
    if p.name == '__pycache__' or p.suffix == '.pyc' or p.name in {'.DS_Store', 'Thumbs.db'} or p.suffix in {'.tmp', '.bak', '.swp'}:
        errors.append(f'forbidden cache file: {rel}')
    if p.is_file() and re.search(r'(^|/)(CHANGELOG|RELEASE_NOTES|RELEASE_MANIFEST|VERSION)$', rel):
        errors.append(f'forbidden release/version file: {rel}')
    if p.is_file() and re.search(r'(20260606|REBUILD|REPAIR|VALIDATION_EVIDENCE|WINDOWS_CODE_AUDIT|RUNTIME_COMPATIBILITY)', rel, re.I):
        errors.append(f'forbidden dated/update artifact: {rel}')

required = [
    'README.md', 'SKILL.md', 'package.json', 'requirements.txt',
    'docs/capabilities.md', 'docs/document_map.md', 'docs/routing.md',
    'docs/quality_gate.md', 'docs/runbook.md', 'docs/maintenance.md',
    'templates/evidence.json', 'schemas/evidence.schema.json',
    'tests/trigger_cases.json', 'tests/samples/insufficient_manifest.json',
    '12-skill-review/SKILL.md', '13-second-review/SKILL.md',
    '14-evidence-court/SKILL.md', '15-asset-audit/SKILL.md',
    '16-param-model/SKILL.md', '17-browser-replay/SKILL.md',
    '18-param-diff/SKILL.md', '19-severe-check/SKILL.md',
    '20-self-audit/SKILL.md', '21-runtime-evidence/SKILL.md',
    '22-schema-parser/SKILL.md', '23-oss-env-gate/SKILL.md',
    'installers/install.sh', 'installers/install.ps1',
    'tools/windows/install.ps1', 'tools/windows/validate.ps1', 'tools/windows/import-authorized-target.ps1',
    'tools/windows/run.cmd', 'tools/windows/validate.cmd',
    'scripts/env_check.py', 'scripts/run.mjs',
    'scripts/windows_check.py', 'scripts/windows_validate.py',
    'scripts/collect_assets.py', 'scripts/analyze_assets.py', 'scripts/quality_gate.py',
    'scripts/runtime_bridge.py', 'scripts/role_tenant_diff.py',
    'scripts/playwright_replay.py', 'scripts/backend_probe.py',
    'scripts/report.py', 'scripts/api_model.py',
    'scripts/param_diff.py', 'scripts/browser_plan.py',
    'scripts/severe_map.py', 'scripts/self_audit.py',
    'scripts/fixture_tests.py', 'scripts/check_audit_assets.py',
    'scripts/runtime_import.py', 'scripts/evidence_manifest.py',
    'scripts/gql_ws_replay.py', 'scripts/wrapper_resolve.py',
    'scripts/sourcemap_recon.py', 'scripts/cdn_assets.py',
    'scripts/sw_cache.py', 'scripts/build_parser.py',
    'scripts/schema_align.py', 'scripts/hidden_features.py',
    'scripts/flow_templates.py', 'scripts/evidence_dash.py',
    'scripts/oss_registry.py', 'scripts/oss_replay.py',
    'scripts/auth_target_gate.py', 'scripts/role_tenant_replay.py',
    'scripts/hidden_param_matrix.py', 'scripts/runtime_bind.py',
    'scripts/semantic_graph.py', 'scripts/detector_run.py',
    'scripts/scope_guard.py', 'scripts/schema_check.py', 'scripts/adversarial_test.py',
    'scripts/unit_tests.py', 'scripts/full_validate.py', 'scripts/p1_validate.py',
    'scripts/backends/js/babel_ast.mjs', 'scripts/backends/js/ts_ast.mjs',
    'schemas/audit-ledger.schema.json', 'schemas/audit-finding.schema.json',
    'schemas/api-parameter-model.schema.json', 'schemas/backend-param-diff.schema.json',
    'schemas/browser-replay-plan.schema.json', 'schemas/runtime-evidence.schema.json',
    'schemas/backend-acceptance-evidence.schema.json', 'schemas/severe-candidate-map.schema.json',
    'schemas/self-audit-matrix.schema.json', 'schemas/evidence.schema.json',
    'schemas/wrapper-resolution.schema.json', 'schemas/sourcemap-reconstruction.schema.json',
    'schemas/cdn-history-assets.schema.json', 'schemas/service-worker-cache-audit.schema.json',
    'schemas/framework-build-artifacts.schema.json', 'schemas/schema-alignment.schema.json',
    'schemas/hidden-feature-signals.schema.json', 'schemas/business-flow-templates.schema.json',
    'schemas/graphql-ws-runtime-replay.schema.json', 'schemas/oss-replay-registry.schema.json',
    'schemas/env-check.schema.json', 'schemas/windows-env-check.schema.json',
    'schemas/windows-validation-run.schema.json', 'schemas/runtime-artifact-bundle.schema.json',
    'schemas/authorized-target-import.schema.json', 'schemas/role-tenant-authorization-result.schema.json',
    'schemas/hidden-param-acceptance-matrix.schema.json', 'schemas/runtime-detector-binding.schema.json',
    'schemas/real-oss-replay-result.schema.json', 'schemas/semantic-graph.schema.json',
    'schemas/detector-finding.schema.json', 'schemas/detector-registry.schema.json',
    'schemas/adversarial-result.schema.json', 'schemas/scope.schema.json',
    'templates/audit_report.md', 'templates/api_model.md',
    'templates/hidden_param.md', 'templates/browser_plan.md',
    'templates/runtime_evidence.md', 'templates/backend_accept.md',
    'templates/self_audit.md', 'templates/evidence_manifest.md',
    'templates/oss_replay.md', 'templates/business_flow.md',
    'templates/detector_finding.md',
    'knowledge/audit_playbook.md', 'knowledge/hidden_params.md',
    'knowledge/runtime_evidence.md', 'knowledge/schema_parsing.md',
    'data/asset_collectors.json', 'data/asset_detectors.json',
    'data/quality_caps.json', 'data/runtime_requirements.json',
    'data/hidden_param_rules.json', 'data/browser_actions.json',
    'data/detectors.json',
    'fixtures/audit-samples/app/index.html',
    'fixtures/audit-samples/app/static/js/app.js',
    'fixtures/audit-samples/app/static/js/app.js.map',
    'fixtures/hidden-param/frontend/app.js',
    'fixtures/hidden-param/backend/users_controller.ts',
    'fixtures/hidden-param/sample.har',
    'fixtures/runtime-replay/graphql-ws-scenarios.json',
    'fixtures/runtime-import/artifact-origin.json',
    'fixtures/adversarial/cases.json',
    'fixtures/semantic-sample/app.js',
]

for r in required:
    if not (root / r).exists():
        errors.append(f'missing required file: {r}')

knowledge_files = [p for p in (root / 'knowledge').glob('*') if p.is_file()] if (root / 'knowledge').exists() else []
template_files = [p for p in (root / 'templates').glob('*') if p.is_file()] if (root / 'templates').exists() else []
if len(knowledge_files) < 8:
    errors.append('knowledge preservation check failed: expected at least 8 knowledge files')
if len(template_files) < 18:
    errors.append('template preservation check failed: expected at least 18 template files')

pkg_path = root / 'package.json'
if pkg_path.exists():
    try:
        pkg = json.loads(pkg_path.read_text(encoding='utf-8'))
        if 'version' in pkg:
            errors.append('package.json must not carry release/version metadata in the cleaned package')
        scripts = pkg.get('scripts', {})
        if scripts.get('windows:validate') != 'node scripts/run.mjs windows:validate':
            errors.append('package.json windows:validate must use the cross-platform runner')
    except Exception as e:
        errors.append(f'package.json parse failed: {e}')

print(json.dumps({'ok': not errors, 'errors': errors}, ensure_ascii=False, indent=2))
raise SystemExit(1 if errors else 0)
