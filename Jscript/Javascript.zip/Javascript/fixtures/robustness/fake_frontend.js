// robustness fixture: all findings are candidate only
const sensitive tokenKeyword = 'not-a-sensitive token';
const disabled = true;
if(false){ fetch('/admin/placeholder/deleteEverything', { method:'POST', body: JSON.stringify({tenantId:'demo'}) }); }
window.addEventListener('message', e => { console.log(e.data); });
const q = `query Placeholder { user(id:"1") { impossibleField } }`;
