# Regression Test Plan

覆盖：正常任务、模糊任务、负样本、误触发、漏触发、文档冲突、文档缺失、路径无证据表述、工具无证据表述、Prompt Injection、输出格式、质量门禁、多 Skill 协作、最小路径、专家路径。

运行：`python3 scripts/trigger_tests.py` 和 `python3 scripts/package_check.py .`。


## 严格评审回归

1. `python scripts/check_review_assets.py .` 必须通过。
2. `python scripts/skill_review.py . --json-out tests/last-skill-review.json --markdown tests/last-skill-review.md` 必须生成 JSON 与 Markdown。
3. 当 Markdown 声明 Babel/TypeScript/tree-sitter/Playwright/Burp/HAR 但没有对应脚本时，报告必须降级为 `doc-only` 或 `partial`，不能输出 `ready`。
4. 当包中出现 `__pycache__`、`.pyc`、`.tmp`、`.bak`、`.swp`、`.DS_Store`、`Thumbs.db` 时，`package_self_check.py` 必须未通过。


## 第二轮反向审查回归

```bash
python scripts/check_second_assets.py .
python scripts/second_review.py . --json-out tests/last-second-pass-review.json --markdown tests/last-second-pass-review.md
```

验收：

- JSON 中 `corrected_scores.总分` 存在。
- 没有真实 parser backend 时，`runtime_evidence.parser_backend` 必须为空。
- 没有 Playwright/Burp/HAR bridge 时，`runtime_evidence.runtime_bridge` 必须为空。
- 没有 detector harness 时，`runtime_evidence.detectors` 必须为空。
- Markdown 必须包含 9 个主章节。


## Final Evidence Review Regression

```bash
python scripts/evidence_review.py . --json tests/last-final-evidence-review.json --md tests/last-final-evidence-review.md
python scripts/check_review_assets.py .
python scripts/package_check.py .
```

验收：输出必须包含 20 起 JS 收集漏报案例、10 类未证实能力识别、30 类重要问题漏报、工程复盘、未通过扣分评分和必须处理 必需项。没有真实 runtime backend 的能力必须降级。


## JS Top Tier fixture 回归

```bash
python scripts/check_audit_assets.py .
python scripts/fixture_tests.py .
```

验收：必须收集 JS、Source Map、GraphQL/WebSocket 候选，并在缺动态证据时保持 `not-advanced`。
