# 重要 JS 问题链分类

用于 12-skill-review 审查问题发现能力是否覆盖重要链，而不是只覆盖低危扫描项。

## 必须按链路审查

1. 前端泄露 endpoint/route/config 只能证明入口存在；必须追到后端权限、租户隔离、业务对象或敏感操作。
2. DOM sink issue 必须给 source、sink、传播链、上下文、浏览器触发证据和账户影响。
3. postMessage 必须检查 origin 校验、message schema、token/PII 可达性、父子窗口关系和账户影响。
4. GraphQL 必须检查 introspection、hidden mutation、object id、tenant id、role-only schema、错误回显和批量查询。
5. Electron/Extension/WebView 必须检查边界：renderer/content script/webview 到 privileged context 的消息与权限升级。
6. Source map、env、bucket、Firebase/Supabase 配置必须证明实际未授权读写或可达敏感逻辑，不能只报“发现配置”。

## 误报降级

缺动态证据、缺双账号、缺反证、仅前端可见、仅管理员功能、仅配置示例、仅测试数据、仅报错堆栈，必须降级为 candidate、insufficient_evidence 或 not_reportable。
