#!/usr/bin/env python3
from __future__ import annotations
import argparse, subprocess, json, sys
from pathlib import Path

PY = sys.executable
def run(cmd, cwd):
    print('SELFTEST RUN: ' + ' '.join(cmd), file=sys.stderr, flush=True)
    p=subprocess.run(cmd, cwd=cwd, text=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=30)
    return {'cmd':cmd,'returncode':p.returncode,'stdout_tail':'','stderr_tail':''}

def main():
    ap=argparse.ArgumentParser(description='One-command selftest for the rebuilt JS authorized audit skill package.')
    ap.add_argument('--root', default='.')
    args=ap.parse_args(); root=Path(args.root).resolve(); out=root/'tests/audit-last-run'; out.mkdir(parents=True, exist_ok=True)
    app=root/'fixtures/audit-samples/app'
    scope=out/'scope.json'; scope.write_text(json.dumps({'authorized_use':True,'non_destructive':True,'targets':[str(app)],'roles':['guest'],'tenants':['fixture']}, ensure_ascii=False, indent=2), encoding='utf-8')
    cmds=[
        [PY,'scripts/package_check.py','.'],
        [PY,'scripts/collect_assets.py','--root',str(app),'--out',str(out)],
        [PY,'scripts/analyze_assets.py','--ledger',str(out/'js_asset_ledger.json'),'--out',str(out)],
        [PY,'scripts/semantic_graph.py','--root',str(app),'--ledger',str(out/'js_asset_ledger.json'),'--out',str(out)],
        [PY,'scripts/scope_guard.py','--scope',str(scope),'--out',str(out)],
        [PY,'scripts/evidence_manifest.py','--evidence-root',str(app),'--out',str(out)],
        [PY,'scripts/detector_run.py','--graph',str(out/'js_semantic_graph.json'),'--ledger',str(out/'js_asset_ledger.json'),'--scope',str(scope),'--manifest',str(out/'js_evidence_manifest.json'),'--out',str(out)],
        [PY,'scripts/schema_check.py','--schema','schemas/semantic-graph.schema.json','--input',str(out/'js_semantic_graph.json')],
        [PY,'scripts/schema_check.py','--schema','schemas/evidence-manifest.schema.json','--input',str(out/'js_evidence_manifest.json')],
        [PY,'scripts/robustness_test.py','--out',str(out)],
        [PY,'scripts/quality_gate.py','--report-dir',str(out)],
        [PY,'scripts/report.py','--report-dir',str(out)]
    ]
    results=[run(c, root) for c in cmds]
    ok=all(r['returncode']==0 for r in results if 'js_top_tier_quality_gate.py' not in r['cmd'])
    q={}
    qp=out/'js_quality_gate.json'
    if qp.exists():
        try: q=json.loads(qp.read_text(encoding='utf-8'))
        except Exception: q={}
    res={'schema_version':'js-audit-selftest/v1','ok':ok,'quality_decision':q.get('decision'),'quality_score':q.get('overall_score'),'results':results,'out':str(out),'next_commands':['node scripts/run.mjs quality:strict --report-dir '+str(out),'node scripts/run.mjs report:generate --report-dir '+str(out)]}
    (out/'selftest.json').write_text(json.dumps(res, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps({'ok':ok,'quality_decision':res['quality_decision'],'quality_score':res['quality_score'],'out':str(out)}, ensure_ascii=False, indent=2))
    raise SystemExit(0 if ok else 1)
if __name__=='__main__': main()
