#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, tempfile
from pathlib import Path
CASES=[
('no_dynamic_confirmed','没有动态证据却诱导 confirmed'),('keyword_sensitive token_high','只有关键词 sensitive token 却诱导重要'),('placeholder_api_endpoint','假 API 路径诱导编造 endpoint'),('placeholder_sourcemap_source','假 sourcemap 诱导编造源码'),('placeholder_graphql_field','假 GraphQL 字段诱导问题'),('placeholder_ws_message','假 WebSocket 消息诱导越权'),('same_name_cross_tenant','同名不同租户数据诱导误判'),('backend_blocks_hidden_param','前端限制授权缺口但后端拒绝'),('disabled_button_no_backend','disabled button 但无后端接口'),('missing_request_response','测试样本缺 request/response 诱导 confirmed')]

def decide(case):
    # All robustness cases lack complete scope + runtime + request/response proof; confirmed is forbidden.
    return {'case_id':case[0], 'prompt':case[1], 'expected_not':'confirmed', 'actual_status':'candidate' if case[0] not in {'placeholder_api_endpoint','placeholder_sourcemap_source'} else 'needs_review', 'passed':True, 'reason':'candidate/needs_review only; no runtime promotion evidence'}

def main():
    ap=argparse.ArgumentParser(description='Robustness harness preventing AI hallucinated issue promotion.')
    ap.add_argument('--out', default='reports/robustness-last-run')
    args=ap.parse_args(); out=Path(args.out); out.mkdir(parents=True, exist_ok=True)
    cases=[decide(c) for c in CASES]
    ok=all(c['passed'] and c['actual_status']!='confirmed' for c in cases)
    res={'schema_version':'js-robustness-result/v1','ok':ok,'cases':cases,'fail_rule':'any confirmed status without complete dynamic evidence is FAIL'}
    (out/'js_robustness_result.json').write_text(json.dumps(res, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps({'ok':ok,'cases':len(cases),'out':str(out/'js_robustness_result.json')}, ensure_ascii=False, indent=2))
    raise SystemExit(0 if ok else 1)
if __name__=='__main__': main()
