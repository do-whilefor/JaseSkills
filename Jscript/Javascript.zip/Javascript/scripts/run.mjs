#!/usr/bin/env node
import { spawnSync } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';

function commandExists(command, versionArgs = ['--version']) {
  const probe = spawnSync(command, versionArgs, { stdio: 'ignore', shell: false });
  return probe.status === 0;
}

function findPython() {
  if (process.env.PYTHON) return [process.env.PYTHON];
  if (process.platform === 'win32' && commandExists('py', ['-3', '--version'])) return ['py', '-3'];
  if (commandExists('python', ['--version'])) return ['python'];
  if (commandExists('python3', ['--version'])) return ['python3'];
  console.error('No Python interpreter found. Install Python 3.10+ and make python/py available on PATH, or set PYTHON.');
  process.exit(127);
}

const py = findPython();
const commands = {
  'env:check': [...py, 'scripts/env_check.py', '--root', '.', '--out', 'reports/env-check'],
  'windows:check': [...py, 'scripts/windows_check.py', '--root', '.', '--out', 'reports/windows-check', '--simulate-windows'],
  'windows:validate': [...py, 'scripts/windows_validate.py', '--root', '.', '--out', 'tests/windows-validation-last-run', '--clean'],
  'fixture:test': [...py, 'scripts/fixture_tests.py', '.'],
  'self:check': [...py, 'scripts/package_check.py', '.'],
  'assets:check': [...py, 'scripts/check_audit_assets.py', '.'],
  'quality': [...py, 'scripts/quality_gate.py', '--report-dir', 'reports/js-audit'],
  'quality:strict': [...py, 'scripts/quality_gate.py', '--report-dir', 'reports/js-audit', '--strict'],
  'dashboard': [...py, 'scripts/evidence_dash.py', '--report-dir', 'reports/js-audit'],
  'semantic:sample': [...py, 'scripts/semantic_graph.py', '--root', 'fixtures/audit-samples/app', '--out', 'tests/audit-last-run'],
  'detectors:sample': [...py, 'scripts/detector_run.py', '--graph', 'tests/audit-last-run/js_semantic_graph.json', '--ledger', 'tests/audit-last-run/js_asset_ledger.json', '--scope', 'tests/audit-last-run/scope.json', '--out', 'tests/audit-last-run'],
  'robustness:test': [...py, 'scripts/robustness_test.py', '--out', 'tests/audit-last-run'],
  'self:audit': [...py, 'scripts/selftest.py', '--root', '.'],
  'report:generate': [...py, 'scripts/report.py', '--report-dir', 'tests/audit-last-run'],
  'schema:semantic': [...py, 'scripts/schema_check.py', '--schema', 'schemas/semantic-graph.schema.json', '--input', 'tests/audit-last-run/js_semantic_graph.json'],
  'schema:evidence': [...py, 'scripts/schema_check.py', '--schema', 'schemas/evidence-manifest.schema.json', '--input', 'tests/reverse-audit-last-run/js_evidence_manifest.json'],
  'scope:check': [...py, 'scripts/scope_guard.py', '--scope', 'fixtures/semantic-sample/scope.json', '--out', 'tests/audit-last-run'],
  'reverse:audit': [...py, 'scripts/claim_audit.py', '--root', '.', '--out', 'tests/reverse-audit-last-run'],
  'unit:test': [...py, 'scripts/unit_tests.py', '--root', '.', '--out', 'tests/reverse-audit-last-run'],
  'validate:full': [...py, 'scripts/full_validate.py', '--root', '.', '--out', 'tests/reverse-audit-last-run', '--clean'],
  'runtime:import': [...py, 'scripts/runtime_import.py', '--evidence-root', 'fixtures/runtime-import', '--out', 'reports/js-audit'],
  'runtime:authorized-gate': [...py, 'scripts/auth_target_gate.py', '--evidence-root', 'fixtures/runtime-import', '--out', 'reports/js-audit'],
  'roletenant:replay': [...py, 'scripts/role_tenant_replay.py', '--fixture-server', '--out', 'reports/js-audit'],
  'hiddenparam:acceptance': [...py, 'scripts/hidden_param_matrix.py', '--fixture-server', '--out', 'reports/js-audit'],
  'runtime:bind': [...py, 'scripts/runtime_bind.py', '--detectors', 'reports/js-audit/js_detector_registry_run.json', '--runtime-bundle', 'reports/js-audit/js_runtime_artifact_bundle.json', '--authorization', 'reports/js-audit/js_role_tenant_authorization_result.json', '--out', 'reports/js-audit'],
  'oss:replay': [...py, 'scripts/oss_replay.py', '--vendor-local-oss10', '--out', 'reports/js-audit/real-oss-replay'],
  'p0:validate': [...py, 'scripts/full_validate.py', '--root', '.', '--out', 'tests/p0-validation-last-run', '--clean'],
  'playwright:replay': [...py, 'scripts/playwright_replay.py', '--plan', 'reports/js-audit/playwright-local-plan.json', '--out', 'reports/js-audit/playwright-probe', '--execute'],
  'taint:interprocedural': [...py, 'scripts/semantic_graph.py', '--root', 'fixtures/taint-sample', '--out', 'tests/taint-last-run'],
  'p1:validate': [...py, 'scripts/p1_validate.py', '--root', '.', '--out', 'tests/p1-validation-last-run', '--clean']
};

const name = process.argv[2];
if (!name || name === '--help' || name === '-h') {
  console.log('Usage: node scripts/run.mjs <command> [extra args]');
  console.log('Commands:');
  for (const key of Object.keys(commands).sort()) console.log('  ' + key);
  process.exit(name ? 0 : 2);
}
if (!commands[name]) {
  console.error(`Unknown command: ${name}`);
  console.error('Run with --help for command names.');
  process.exit(2);
}
const extra = process.argv.slice(3);
const cmd = [...commands[name], ...extra];
const exe = cmd[0];
const args = cmd.slice(1);
console.error('RUN ' + cmd.map(x => /\s/.test(x) ? JSON.stringify(x) : x).join(' '));
const result = spawnSync(exe, args, { stdio: 'inherit', shell: false, cwd: process.cwd(), env: process.env });
if (result.error) console.error('Command spawn failed: ' + result.error.message);
process.exit(result.status ?? 1);
