#!/usr/bin/env python3
from __future__ import annotations
import json, sys
from pathlib import Path
root=Path(sys.argv[1] if len(sys.argv)>1 else '.').resolve()
required={
 '13-second-review/SKILL.md':1,
 'scripts/second_review.py':1,
 'scripts/check_second_assets.py':1,
 'schemas/second-review.schema.json':1,
 'templates/second_review.md':1,
 'docs/second_review.md':1,
 'knowledge/fidelity_rules.md':1,
 'data/second_checks.json':8,
 'data/second_collection.json':30,
 'data/second_caps.json':20,
 'data/second_risk_chains.json':25,
 'data/second_unusual_points.json':40,
 'data/second_score_rules.json':1,
 'fixtures/second-negative/placeholder-ready-ast.json':1,
 'fixtures/second-blocked/static-candidate-as-verified.json':1,
 'fixtures/second-pass-needs-review/doc-only-runtime-bridge.json':1,
}
errors=[]
for rel,min_count in required.items():
    p=root/rel
    if not p.exists():
        errors.append(f'missing: {rel}'); continue
    if p.suffix=='.json':
        data=json.loads(p.read_text(encoding='utf-8'))
        count=len(data) if isinstance(data,list) else 1
        if count < min_count:
            errors.append(f'too few entries: {rel} has {count}, need {min_count}')
    elif not p.read_text(encoding='utf-8', errors='ignore').strip():
        errors.append(f'empty: {rel}')
print(json.dumps({'ok':not errors,'errors':errors}, ensure_ascii=False, indent=2))
raise SystemExit(1 if errors else 0)
