#!/usr/bin/env python3
from __future__ import annotations
import json, sys, subprocess
from pathlib import Path
root = Path(sys.argv[1] if len(sys.argv)>1 else '.').resolve()
required = [
 '14-evidence-review/SKILL.md',
 'scripts/evidence_review.py',
 'scripts/check_review_assets.py',
 'schemas/evidence-review.schema.json',
 'templates/evidence_review.md',
 'docs/evidence_review.md',
 'knowledge/evidence_rules.md',
 'data/review_prior_check.json',
 'data/review_cases.json',
 'data/review_claim_caps.json',
 'data/review_gap_risks.json',
 'data/review_engineering.json',
 'data/review_score_rules.json',
 'data/review_required.json',
 'data/review_findings.json',
 'templates/evidence_review.md',
]
errors=[]
for rel in required:
    if not (root/rel).exists(): errors.append(f'missing: {rel}')
# cardinality checks
checks = {
 'data/review_cases.json':20,
 'data/review_claim_caps.json':10,
 'data/review_gap_risks.json':30,
 'data/review_engineering.json':10,
 'data/review_required.json':10,
}
for rel, min_items in checks.items():
    if (root/rel).exists():
        try:
            data=json.loads((root/rel).read_text(encoding='utf-8'))
            if len(data) < min_items: errors.append(f'{rel}: expected >= {min_items}, got {len(data)}')
        except Exception as e:
            errors.append(f'{rel}: invalid json: {e}')
if not errors:
    proc=subprocess.run([sys.executable, str(root/'scripts/evidence_review.py'), str(root)], text=True, capture_output=True)
    if proc.returncode != 0:
        errors.append('final_evidence_review_audit failed: ' + proc.stdout + proc.stderr)
print(json.dumps({'ok': not errors, 'errors': errors}, ensure_ascii=False, indent=2))
raise SystemExit(1 if errors else 0)
